library(testthat)
library(rbcb)

test_check("rbcb")
