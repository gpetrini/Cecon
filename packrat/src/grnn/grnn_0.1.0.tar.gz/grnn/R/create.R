create.grnn <- function() {
    nn <- list(
        model="General regression neural network",
        set=NULL
    )
    return(nn)
}
